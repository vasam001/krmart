/**
 * 
 */
package com.superMarket.mart.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.superMarket.mart.model.LoginDetails;
import com.superMarket.mart.model.LoginResponse;

/**
 * @author kiran
 *
 */
@Service
public class LoginService {
	@Autowired
	LoginResponse loginResponse;
	public LoginResponse loginCheck(LoginDetails loginDetails) {
		if (loginDetails.getUserName().equalsIgnoreCase("kiranreddy")) {
			if (loginDetails.getPassword().equalsIgnoreCase("montree")) {
				loginResponse.setMessage("successfully login welcome to mart");
			} else {
				loginResponse.setMessage("password is incorrect");
			}
		} else {
			loginResponse.setMessage("user is not register");
		}
		return loginResponse;
	}
}
