/**
 * 
 */
package com.superMarket.mart.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

/**
 * @author kiran
 *
 */
@Component
@Entity
@Table (name = "LOGIN_DETAILS")

public class LoginDetails {
	@Id
	@Column(name = "Login_Id")
	long id;
	@Column(name = "User_Name")
	String userName;
	@Column(name = "Password")
	String password;
	
	public LoginDetails() {
		
	}
	public LoginDetails(long id,String userName,String password) {
		this.id = id;
		this.userName = userName;
		this.password = password;
	}
	
	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}
	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}
	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}
	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}
	
	
}
