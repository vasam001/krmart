package com.superMarket.mart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@EnableAutoConfiguration
public class MartApplication {

	public static void main(String[] args) {
		System.out.println("----------before start application------------");
		SpringApplication.run(MartApplication.class, args);
		System.out.println("----------after start application------------");
	}

}
/*
 * 
 * 1. all dependency jars will download based spring boot version 2. inbuilt
 * server 3. create all dependency objects 4. added actuator
 */
